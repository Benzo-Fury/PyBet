from Utility.Colour.colour import red, pinkish_red, blue, green, orange, yellow

strawberry = [
    '         ',
    green('    ##   '),
    red('   ####  '),
    red('   ####  '),
    red('    ##   '),
    red('         '),
]

banana = [
    '         ',
    yellow('      #  '),
    yellow('     ##  '),
    yellow('    ##   '),
    yellow('  ##     '),
    '         ',
]

blueberry = [
    '         ',
    green('    ##   '),
    blue('  ####   '),
    blue(' #####   '),
    blue('  ##     '),
    '         ',
]

raspberry = [
    '         ',
    green('    #    '),
    pinkish_red('   ###   '),
    pinkish_red('  #####  '),
    pinkish_red('   ###   '),
    pinkish_red('         '),
]

orange_fruit = [
    '         ',
    green('     #   '),
    orange('   ###   '),
    orange('  #####  '),
    orange('   ###   '),
    '         ',
]

seven = [
    '         ',
    red('   ####  '),
    red('      #  '),
    red('     #   '),
    red('    #    '),
    '         ',
]